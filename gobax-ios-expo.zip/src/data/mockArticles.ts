export interface Article {
  id: string;
  title: string;
  category: 'Bitcoin' | 'DeFi' | 'Web3' | 'Security' | 'Analysis';
  readTime: string;
  author: string;
  source: string;
  sourceUrl?: string;
  publishedAt: string;
  summary: string;
  imageBg: string;
  content: string[];
  trending?: boolean;
}

export const MOCK_ARTICLES: Article[] = [
  {
    id: 'art-1',
    title: 'Bitcoin Crosses New Milestone: Institutional Inflows Drive Next Supercycle',
    category: 'Bitcoin',
    readTime: '4 min read',
    author: 'Elena Vance',
    source: 'CoinDesk',
    publishedAt: '2 hours ago',
    trending: true,
    imageBg: '#F59E0B',
    summary: 'Global ETF volume and sovereign treasury reserves stimulate sustained upward trajectory as market dynamics shift.',
    content: [
      'The cryptocurrency landscape is experiencing an unprecedented structural shift. Spot ETFs continue to absorb spot liquidity at a pace exceeding daily miner issuances.',
      'According to recent on-chain analytics, long-term holder distribution remains notably suppressed compared to previous halving cycles.',
      'With macroeconomic liquidity easing and institutional custody infrastructure solidifying, analysts predict lower volatility combined with persistent upward baseline accumulation.'
    ]
  },
  {
    id: 'art-2',
    title: 'Gobax Tokenomics 2.0: Staking Yields, Buyback Mechanics & Ecosystem Roadmap',
    category: 'Web3',
    readTime: '6 min read',
    author: 'Gobax Core Devs',
    source: 'Gobax Blog',
    publishedAt: 'Yesterday',
    trending: true,
    imageBg: '#00FFE0',
    summary: 'Discover how the newly audited GOBX smart contracts distribute protocol trading revenue directly to active community stakers.',
    content: [
      'We are thrilled to unveil the updated architecture of the Gobax tokenomics framework. 30% of all platform trading fees are now diverted to auto-compounding LP pools.',
      'Holders who lock GOBX for 90 days or more unlock Tier-1 zero-fee trading perks and early allocation access to upcoming launchpad listings.',
      'Our second-layer cross-chain bridge is currently audited by CertiK with mainnet transition slated for Q3.'
    ]
  },
  {
    id: 'art-3',
    title: 'Zero-Knowledge Proofs in DeFi: Why Privacy & Scale Are Finally Converging',
    category: 'DeFi',
    readTime: '5 min read',
    author: 'Dr. Kevin Zhao',
    source: 'The Block',
    publishedAt: '2 days ago',
    imageBg: '#8B5CF6',
    summary: 'How ZK-rollups eliminate front-running MEV bots while preserving full institutional transaction anonymity.',
    content: [
      'Decentralized finance has historically wrestled with transparent public mempools that leave traders vulnerable to predatory sandwich attacks.',
      'ZK-SNARK-powered execution layers ensure trades are cryptographically verifiable before order sequencing is finalized, creating mathematical guarantees of fair execution.',
      'Liquidity fragmentation is also being combated through recursive proofs, connecting liquidity between disparate layer-2 chains seamlessly.'
    ]
  },
  {
    id: 'art-4',
    title: 'Essential Wallet Security: Protecting Your Private Keys Against Modern Drainers',
    category: 'Security',
    readTime: '3 min read',
    author: 'CyberGuard Security',
    source: 'Decrypt',
    publishedAt: '3 days ago',
    imageBg: '#EF4444',
    summary: 'Phishing techniques have evolved from simple seed-phrase steals to sophisticated ERC-20 permit signature lures.',
    content: [
      'Modern crypto threats rarely attack cryptographic primitives directly; instead, they manipulate human signatures via Permit2 and malicious spender approvals.',
      'Always inspect permit allowances carefully before signing with your hardware or mobile wallet. Never sign transactions requesting infinite spending approvals on unverified dApps.',
      'Use multi-sig vaults for treasury storage and separate cold storage from day-to-day trading wallets.'
    ]
  },
  {
    id: 'art-5',
    title: 'Macro Liquidity Trends & Altcoin Season: Key Indicators to Watch',
    category: 'Analysis',
    readTime: '7 min read',
    author: 'Marcus Sterling',
    source: 'CoinTelegraph',
    publishedAt: '4 days ago',
    imageBg: '#10B981',
    summary: 'Examining global M2 money supply, Bitcoin dominance ratios, and stablecoin inflows to pinpoint market transitions.',
    content: [
      'Historical cycle analysis shows altcoin expansions typically follow stablecoin capitalization surges by approximately 45 to 60 days.',
      'Currently, stablecoin supply on major networks has printed record highs, indicating strong sideline dry powder preparing for deployment.'
    ]
  }
];
